De Bondt Harald
De Cremer Pieter
Goossens Rian
5/11/2015
==================================================
Relevant scripts for first deadline of competition
==================================================
- report_1_feature_extraction_data.py
	Calculates logloss for all our features and several combinations of them
- report_1_image_operation_plots.py
	Generates some of the plots in our report 

The other files are results of all our experiments throughout the semester and various utility modules. You can read these but they are not necessary for the report.